<template>
  <div id="app">
    <router-link to="/sxyd">加载Vue应用</router-link>
    <!-- 子应用加载的位置 -->
    <div id="vue"></div>
  </div>
</template>

<style lang="scss">
</style>
